package com.mum.edu.StockPortfolioManager;

public interface StockService {
	   public double getPrice(Stock stock);
	}

