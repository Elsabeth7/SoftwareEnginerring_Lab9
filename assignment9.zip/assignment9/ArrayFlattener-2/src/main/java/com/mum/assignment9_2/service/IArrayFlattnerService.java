package com.mum.assignment9_2.service;

public interface IArrayFlattnerService {
	public int[] flattenArray(int a_in[][]) ;
}
